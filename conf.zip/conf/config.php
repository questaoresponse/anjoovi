<?php
$GLOBALS["ffprobe_path"]="ffprobe"
?>